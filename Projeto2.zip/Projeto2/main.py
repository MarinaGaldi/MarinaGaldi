from package.menu.menuPrincipal import Menu

menu = Menu()
menu.printMenuInicial()
